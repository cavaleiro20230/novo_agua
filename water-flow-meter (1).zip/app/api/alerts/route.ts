import { NextResponse } from "next/server"
import nodemailer from "nodemailer"

// Configure email transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
})

export async function POST(request: Request) {
  try {
    const { subject, message, recipients, alertType } = await request.json()

    // Validate required fields
    if (!subject || !message || !recipients || recipients.length === 0) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Create email content with HTML formatting
    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0066cc;">${subject}</h2>
        <p>${message.replace(/\n/g, "<br>")}</p>
        <hr>
        <p style="color: #666; font-size: 0.8em;">
          Esta é uma mensagem automática do seu Sistema de Monitoramento de Água.
          Não responda a este email.
        </p>
      </div>
    `

    // Send email
    const mailOptions = {
      from: `"Sistema de Monitoramento de Água" <${process.env.EMAIL_USER}>`,
      to: recipients.join(", "),
      subject: subject,
      text: message,
      html: htmlContent,
    }

    await transporter.sendMail(mailOptions)

    // Log the alert to the database or file system if needed
    // This would be implemented based on your storage preferences

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error sending alert:", error)
    return NextResponse.json({ error: "Failed to send alert" }, { status: 500 })
  }
}

